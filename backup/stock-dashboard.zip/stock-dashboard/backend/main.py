from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import yfinance as yf
import pandas as pd
from typing import List, Dict, Any

app = FastAPI()

# Enable CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

def resolve_symbol(symbol: str) -> str:
    """
    Simple helper to try and resolve WKN/Ticker.
    In a real world scenario, a WKN -> Ticker mapping API would be used.
    For this demo, we'll assume that if it's 6 digits, it's a WKN 
    and we'll try to append '.DE' as a guess for German stocks.
    """
    symbol = symbol.upper().strip()
    # Simple heuristic: if 6 digits, it might be a WKN.
    # Note: This is a naive implementation.
    if symbol.isdigit() and len(symbol) == 6:
        # Try to see if yfinance can find it, otherwise we might need a mapping.
        # Many German WKNs aren't directly supported by yfinance.
        # We'll return as is and let yfinance try, or the user can provide the Ticker.
        return symbol 
    return symbol

@app.get("/price/{symbol}")
async def get_price(symbol: str):
    try:
        ticker_symbol = resolve_symbol(symbol)
        ticker = yf.Ticker(ticker_symbol)
        info = ticker.fast_info
        
        # Use fast_info for speed
        current_price = info.last_price
        previous_close = info.previous_close
        change = current_price - previous_close
        change_percent = (change / previous_close) * 100 if previous_close else 0
        
        return {
            "symbol": ticker_symbol,
            "price": round(current_price, 2),
            "change": round(change, 2),
            "change_percent": round(change_percent, 2),
            "currency": info.currency
        }
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Could not find data for {symbol}. Please try the Ticker symbol (e.g., SAP.DE). Error: {str(e)}")

@app.get("/history/{symbol}")
async def get_history(symbol: str):
    try:
        ticker_symbol = resolve_symbol(symbol)
        ticker = yf.Ticker(ticker_symbol)
        # Get 1 month of daily data
        hist = ticker.history(period="1mo")
        if hist.empty:
            raise HTTPException(status_code=404, detail="No history found")
            
        prices = hist['Close'].tolist()
        return {
            "symbol": ticker_symbol,
            "prices": [round(p, 2) for p in prices]
        }
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Error fetching history for {symbol}: {str(e)}")

@app.get("/news/{symbol}")
async def get_news(symbol: str):
    try:
        ticker_symbol = resolve_symbol(symbol)
        ticker = yf.Ticker(ticker_symbol)
        news = ticker.news
        
        result = []
        for item in news[:5]: # Top 5 news
            result.append({
                "title": item.get("title"),
                "publisher": item.get("publisher"),
                "link": item.get("link"),
                "providerPublishTime": item.get("providerPublishTime")
            })
        return result
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Error fetching news for {symbol}: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
