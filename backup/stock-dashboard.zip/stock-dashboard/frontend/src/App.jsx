import React, { useState, useEffect } from 'react';
import axios from 'axios';
import StockCard from './components/StockCard';
import NewsPanel from './components/NewsPanel';
import AddStock from './components/AddStock';

const API_BASE = process.env.NODE_ENV === 'production' 
  ? 'http://localhost:8000' 
  : 'http://localhost:8000'; // In Docker, this might need to be the service name

const App = () => {
  const [stocks, setStocks] = useState(() => {
    const saved = localStorage.getItem('watchlist');
    return saved ? JSON.parse(saved) : [];
  });
  const [stockData, setStockData] = useState({});
  const [historyData, setHistoryData] = useState({});
  const [selectedStock, setSelectedStock] = useState(null);
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    localStorage.setItem('watchlist', JSON.stringify(stocks));
  }, [stocks]);

  const fetchData = async () => {
    const newData = {};
    const newHist = {};
    
    for (const symbol of stocks) {
      try {
        const priceRes = await axios.get(`${API_BASE}/price/${symbol}`);
        const histRes = await axios.get(`${API_BASE}/history/${symbol}`);
        newData[symbol] = priceRes.data;
        newHist[symbol] = histRes.data.prices.map((p, i) => ({ price: p, date: i }));
      } catch (e) {
        console.error(`Error fetching ${symbol}:`, e);
      }
    }
    setStockData(newData);
    setHistoryData(newHist);
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 60000); // Update every minute
    return () => clearInterval(interval);
  }, [stocks]);

  const handleStockSelect = async (symbol) => {
    setSelectedStock(symbol);
    try {
      const res = await axios.get(`${API_BASE}/news/${symbol}`);
      setNews(res.data);
    } catch (e) {
      setNews([]);
    }
  };

  const addStock = async (symbol) => {
    setLoading(true);
    setError(null);
    try {
      // Verify if stock exists
      await axios.get(`${API_BASE}/price/${symbol}`);
      if (!stocks.includes(symbol)) {
        setStocks([...stocks, symbol]);
      }
    } catch (e) {
      setError(`Could not find ${symbol}. Try a different symbol or Ticker (e.g. SAP.DE).`);
    } finally {
      setLoading(false);
    }
  };

  const removeStock = (symbol) => {
    setStocks(stocks.filter(s => s !== symbol));
    if (selectedStock === symbol) {
      setSelectedStock(null);
      setNews([]);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <header className="mb-10 flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-bold tracking-tighter uppercase">Stock_Dashboard_v1</h1>
          <p className="text-xs-mono text-muted">Industrial Market Monitor // Status: Online</p>
        </div>
        <div className="text-right text-xs-mono text-muted">
          {new Date().toLocaleDateString()} | {new Date().toLocaleTimeString()}
        </div>
      </header>

      <AddStock onAdd={addStock} />
      {error && <p className="text-red-500 text-xs-mono mb-4">{error}</p>}
      {loading && <p className="text-muted text-xs-mono mb-4 animate-pulse">Verifying symbol...</p>}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
          {stocks.length === 0 && (
            <div className="col-span-full text-center p-10 border border-dashed border-accent text-muted text-xs-mono">
              WATCHLIST EMPTY. ADD SYMBOLS ABOVE.
            </div>
          )}
          {stocks.map(symbol => (
            <div 
              key={symbol} 
              onClick={() => handleStockSelect(symbol)}
              className={`cursor-pointer transition-all ${selectedStock === symbol ? 'ring-1 ring-white' : ''}`}
            >
              <StockCard 
                stock={stockData[symbol] || { symbol, price: '...', change: 0, change_percent: 0, currency: '...' }} 
                history={historyData[symbol] || []} 
                onRemove={removeStock} 
              />
            </div>
          ))}
        </div>

        <div className="bg-surface border border-accent min-h-[400px]">
          <NewsPanel news={news} symbol={selectedStock} />
        </div>
      </div>
    </div>
  );
};

export default App;
