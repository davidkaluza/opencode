import React from 'react';
import { LineChart, Line, ResponsiveContainer } from 'recharts';
import { Trash2 } from 'lucide-react';

const StockCard = ({ stock, history, onRemove }) => {
  const isPositive = stock.change >= 0;

  return (
    <div className="bg-surface border border-accent p-3 flex flex-col gap-2 hover:border-muted transition-colors">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-sm-mono font-bold uppercase">{stock.symbol}</h3>
          <p className="text-xs-mono text-muted">{stock.currency}</p>
        </div>
        <button 
          onClick={() => onRemove(stock.symbol)}
          className="text-muted hover:text-red-500 transition-colors"
        >
          <Trash2 size={12} />
        </button>
      </div>

      <div className="flex items-baseline gap-2">
        <span className="text-lg font-bold">{stock.price}</span>
        <span className={`text-xs-mono ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
          {isPositive ? '+' : ''}{stock.change} ({stock.change_percent}%)
        </span>
      </div>

      <div className="h-12 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={history}>
            <Line 
              type="monotone" 
              dataKey="price" 
              stroke={isPositive ? '#22c55e' : '#ef4444'} 
              strokeWidth={1.5} 
              dot={false} 
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default StockCard;
